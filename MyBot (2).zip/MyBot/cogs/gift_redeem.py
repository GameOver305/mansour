import discord
from discord.ext import commands
import aiohttp
import json
import os

def load_lang(lang_code):
    path = f"lang/{lang_code}.json"
    if not os.path.exists(path):
        path = "lang/ar.json"
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def load_config():
    if not os.path.exists("config.json"):
        return {"default_lang": "ar", "admins": []}
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

class GiftRedeem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def is_admin(self, user_id):
        cfg = load_config()
        return user_id in cfg.get("admins", [])

    async def redeem_code(self, uid: str, server: str, code: str):
        api_url = "https://api.whiteoutgame.com/redeem"

        headers = {
            "User-Agent": "Mozilla/5.0",
            "Content-Type": "application/json",
            "X-Bypass-Verification": "true"
        }

        payload = {
            "uid": uid,
            "server": server,
            "code": code,
            "bypass": True
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(api_url, headers=headers, json=payload) as resp:
                try:
                    data = await resp.json()
                except:
                    return {"success": False, "msg": "خطأ في قراءة الرد من API"}

                return data

    @commands.slash_command(name="redeem", description="استرداد هدية")
    async def redeem(self, ctx, uid: str, server: str, code: str):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        await ctx.respond(lang["loading"], ephemeral=True)

        result = await self.redeem_code(uid, server, code)

        if result.get("success"):
            await ctx.edit(content=f"🎉 **تم الاسترداد بنجاح!**\nالنتيجة:\n```{result}```")
        else:
            await ctx.edit(content=f"❌ **فشل الاسترداد**\nالسبب:\n```{result}```")

def setup(bot):
    bot.add_cog(GiftRedeem(bot))