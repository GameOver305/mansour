import discord
from discord.ext import commands
import json
import os
from datetime import datetime

def load_logs():
    if not os.path.exists("logs.json"):
        return {"logs": []}
    with open("logs.json", "r", encoding="utf-8") as f:
        return json.load(f)

def save_logs(data):
    with open("logs.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def load_config():
    if not os.path.exists("config.json"):
        return {"default_lang": "ar", "admins": [], "log_channel": None}
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def save_config(cfg):
    with open("config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=4, ensure_ascii=False)

class Logs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def log_action(self, action, user, details=""):
        logs = load_logs()
        entry = {
            "action": action,
            "user": user,
            "details": details,
            "time": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        }
        logs["logs"].append(entry)
        save_logs(logs)

        cfg = load_config()
        channel_id = cfg.get("log_channel")

        if channel_id:
            channel = self.bot.get_channel(channel_id)
            if channel:
                embed = discord.Embed(
                    title="📌 حدث جديد",
                    color=discord.Color.orange()
                )
                embed.add_field(name="الحدث", value=action, inline=False)
                embed.add_field(name="المستخدم", value=f"<@{user}>", inline=False)
                embed.add_field(name="التفاصيل", value=details or "لا يوجد", inline=False)
                embed.set_footer(text="نظام اللوق")
                self.bot.loop.create_task(channel.send(embed=embed))

    @commands.slash_command(name="set_log_channel", description="تحديد قناة اللوق")
    async def set_log_channel(self, ctx, channel: discord.TextChannel):
        cfg = load_config()
        cfg["log_channel"] = channel.id
        save_config(cfg)

        await ctx.respond(f"تم تحديد قناة اللوق: {channel.mention}")

def setup(bot):
    bot.add_cog(Logs(bot))