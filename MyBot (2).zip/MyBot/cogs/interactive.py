import discord
from discord.ext import commands
import json
import os

def load_teams():
    if not os.path.exists("teams.json"):
        return {}
    with open("teams.json", "r", encoding="utf-8") as f:
        return json.load(f)

class TeamSelect(discord.ui.Select):
    def __init__(self):
        teams = load_teams()
        options = [
            discord.SelectOption(label=name, description="اضغط لعرض معلومات الفريق")
            for name in teams
        ]

        if not options:
            options = [discord.SelectOption(label="لا يوجد فرق", description="قم بإنشاء فريق أولاً")]

        super().__init__(
            placeholder="اختر فريقاً",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction):
        team_name = self.values[0]
        teams = load_teams()

        if team_name not in teams:
            return await interaction.response.send_message("الفريق غير موجود.", ephemeral=True)

        data = teams[team_name]

        leaders = "\n".join([f"<@{i}>" for i in data["leaders"]]) or "لا يوجد"
        members = "\n".join([f"<@{i}>" for i in data["members"]]) or "لا يوجد"

        embed = discord.Embed(
            title=f"فريق: {team_name}",
            color=discord.Color.green()
        )
        embed.add_field(name="القادة", value=leaders, inline=False)
        embed.add_field(name="الأعضاء", value=members, inline=False)

        await interaction.response.send_message(embed=embed, ephemeral=True)

class TeamSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TeamSelect())

class Interactive(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(name="teams_menu", description="قائمة الفرق التفاعلية")
    async def teams_menu(self, ctx):
        await ctx.respond("اختر فريقاً من القائمة:", view=TeamSelectView(), ephemeral=True)

def setup(bot):
    bot.add_cog(Interactive(bot))