# ─────────────────────────────────────────────
# ملف: rank_system.py (يدعم العربية + الإنجليزية)
# ─────────────────────────────────────────────

import discord
from discord.ext import commands
from discord.ui import View, Button
import json
import os

RANK_DATA = "data/ranks.json"
LANG_DATA = "data/language.json"

def load_ranks():
    if not os.path.exists(RANK_DATA):
        with open(RANK_DATA, "w", encoding="utf-8") as f:
            json.dump({"users": {}, "pending": {}}, f, ensure_ascii=False, indent=4)
    with open(RANK_DATA, "r", encoding="utf-8") as f:
        return json.load(f)

def save_ranks(data):
    with open(RANK_DATA, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def load_lang():
    if not os.path.exists(LANG_DATA):
        with open(LANG_DATA, "w", encoding="utf-8") as f:
            json.dump({"users": {}}, f, ensure_ascii=False, indent=4)
    with open(LANG_DATA, "r", encoding="utf-8") as f:
        return json.load(f)


# ─────────────────────────────────────────────
# زر قبول / رفض طلب الرتبة العالية
# ─────────────────────────────────────────────

class RankApproval(View):
    def __init__(self, user_id, rank):
        super().__init__(timeout=None)
        self.user_id = user_id
        self.rank = rank

        self.add_item(Button(label="✔️ قبول", style=discord.ButtonStyle.success, custom_id=f"approve_{user_id}"))
        self.add_item(Button(label="❌ رفض", style=discord.ButtonStyle.danger, custom_id=f"deny_{user_id}"))


# ─────────────────────────────────────────────
# كوج نظام الرتب
# ─────────────────────────────────────────────

class RankSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):

        if not interaction.data or "custom_id" not in interaction.data:
            return

        cid = interaction.data["custom_id"]
        user = interaction.user

        # تحميل البيانات
        ranks = load_ranks()
        langs = load_lang()

        # لغة العضو
        lang = langs["users"].get(str(user.id), "ar")

        # نصوص حسب اللغة
        txt_request_sent = {
            "ar": "تم إرسال طلبك للحصول على رتبة",
            "en": "Your request for rank"
        }

        txt_rank_saved = {
            "ar": "تم تسجيل رتبتك:",
            "en": "Your rank has been registered:"
        }

        txt_request_accepted = {
            "ar": "✔️ تم قبول طلبك للحصول على رتبة",
            "en": "✔️ Your request for rank has been approved:"
        }

        txt_request_denied = {
            "ar": "❌ تم رفض طلبك للحصول على رتبة عالية.",
            "en": "❌ Your request for a high rank has been denied."
        }

        txt_admin_msg = {
            "ar": "🔔 طلب جديد:\nالعضو طلب رتبة",
            "en": "🔔 New request:\nUser requested rank"
        }

        txt_admin_done = {
            "ar": "تم قبول الطلب.",
            "en": "Request approved."
        }

        txt_admin_denied = {
            "ar": "تم رفض الطلب.",
            "en": "Request denied."
        }

        # ─────────────────────────────
        # اختيار رتبة
        # ─────────────────────────────
        if cid.startswith("rank_"):
            rank = cid.replace("rank_", "")

            # الرتب العالية تحتاج موافقة
            if rank in ["R5", "R4"]:
                ranks["pending"][str(user.id)] = rank
                save_ranks(ranks)

                # إرسال طلب للأدمن
                admin = discord.utils.get(interaction.guild.members, guild_permissions__administrator=True)

                if admin:
                    await admin.send(
                        f"{txt_admin_msg[lang]} **{rank}**",
                        view=RankApproval(user.id, rank)
                    )

                await interaction.response.send_message(
                    f"{txt_request_sent[lang]} **{rank}**.",
                    ephemeral=True
                )
                return

            # الرتب العادية تسجل مباشرة
            ranks["users"][str(user.id)] = {"rank": rank}
            save_ranks(ranks)

            await interaction.response.send_message(
                f"{txt_rank_saved[lang]} **{rank}**",
                ephemeral=True
            )
            return

        # ─────────────────────────────
        # قبول طلب رتبة عالية
        # ─────────────────────────────
        if cid.startswith("approve_"):
            uid = cid.replace("approve_", "")
            rank = ranks["pending"].get(uid)

            if not rank:
                return

            ranks["users"][uid] = {"rank": rank}
            del ranks["pending"][uid]
            save_ranks(ranks)

            member = interaction.guild.get_member(int(uid))
            if member:
                langs = load_lang()
                lang = langs["users"].get(uid, "ar")
                await member.send(f"{txt_request_accepted[lang]} **{rank}**")

            await interaction.response.send_message(txt_admin_done[lang], ephemeral=True)
            return

        # ─────────────────────────────
        # رفض طلب رتبة عالية
        # ─────────────────────────────
        if cid.startswith("deny_"):
            uid = cid.replace("deny_", "")

            if uid in ranks["pending"]:
                del ranks["pending"][uid]
                save_ranks(ranks)

            member = interaction.guild.get_member(int(uid))
            if member:
                langs = load_lang()
                lang = langs["users"].get(uid, "ar")
                await member.send(txt_request_denied[lang])

            await interaction.response.send_message(txt_admin_denied[lang], ephemeral=True)
            return


async def setup(bot):
    await bot.add_cog(RankSystem(bot))