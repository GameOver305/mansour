# ─────────────────────────────────────────────
# ملف: info_system.py (يدعم العربية + الإنجليزية)
# ─────────────────────────────────────────────

import discord
from discord.ext import commands
import json
import os

INFO_DATA = "data/info.json"
LANG_DATA = "data/language.json"

def load_info():
    if not os.path.exists(INFO_DATA):
        with open(INFO_DATA, "w", encoding="utf-8") as f:
            json.dump({
                "ar": {
                    "alliance_info": "معلومات التحالف:\n- هذا النص افتراضي ويمكن تغييره لاحقًا.",
                    "rules": "قوانين السيرفر:\n1- الاحترام واجب.\n2- يمنع السبام.\n3- يمنع الإساءة للأعضاء.",
                    "start_guide": "تعليمات البداية:\n- اختر رتبتك.\n- اختر شارتك.\n- ابدأ استخدام البوت."
                },
                "en": {
                    "alliance_info": "Alliance Information:\n- This is a default text and can be changed later.",
                    "rules": "Server Rules:\n1- Respect is required.\n2- No spam.\n3- No harassment.",
                    "start_guide": "Getting Started:\n- Choose your rank.\n- Choose your badge.\n- Start using the bot."
                }
            }, f, ensure_ascii=False, indent=4)

    with open(INFO_DATA, "r", encoding="utf-8") as f:
        return json.load(f)

def load_lang():
    if not os.path.exists(LANG_DATA):
        with open(LANG_DATA, "w", encoding="utf-8") as f:
            json.dump({"users": {}}, f, ensure_ascii=False, indent=4)
    with open(LANG_DATA, "r", encoding="utf-8") as f:
        return json.load(f)


class InfoSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):

        if not interaction.data or "custom_id" not in interaction.data:
            return

        cid = interaction.data["custom_id"]
        user = interaction.user

        info = load_info()
        langs = load_lang()

        # لغة العضو
        lang = langs["users"].get(str(user.id), "ar")

        # ─────────────────────────────
        # معلومات التحالف
        # ─────────────────────────────
        if cid == "info_alliance":
            await interaction.response.send_message(
                info[lang]["alliance_info"],
                ephemeral=True
            )
            return

        # ─────────────────────────────
        # قوانين السيرفر
        # ─────────────────────────────
        if cid == "rules":
            await interaction.response.send_message(
                info[lang]["rules"],
                ephemeral=True
            )
            return

        # ─────────────────────────────
        # تعليمات البداية
        # ─────────────────────────────
        if cid == "start_guide":
            await interaction.response.send_message(
                info[lang]["start_guide"],
                ephemeral=True
            )
            return


async def setup(bot):
    await bot.add_cog(InfoSystem(bot))