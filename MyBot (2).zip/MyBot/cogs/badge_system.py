# ─────────────────────────────────────────────
# ملف: badge_system.py (نظام شارات كامل)
# ─────────────────────────────────────────────

import discord
from discord.ext import commands
from discord.ui import View, Button
import json
import os

BADGE_DATA = "data/badges.json"
LANG_DATA = "data/language.json"

# ─────────────────────────────────────────────
# تحميل وحفظ البيانات
# ─────────────────────────────────────────────

def load_badges():
    if not os.path.exists(BADGE_DATA):
        with open(BADGE_DATA, "w", encoding="utf-8") as f:
            json.dump({
                "users": {},
                "badges": ["⭐", "⚔️", "🎖️", "🟦", "🔥", "💎"]
            }, f, ensure_ascii=False, indent=4)
    with open(BADGE_DATA, "r", encoding="utf-8") as f:
        return json.load(f)

def save_badges(data):
    with open(BADGE_DATA, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def load_lang():
    if not os.path.exists(LANG_DATA):
        with open(LANG_DATA, "w", encoding="utf-8") as f:
            json.dump({"users": {}}, f, ensure_ascii=False, indent=4)
    with open(LANG_DATA, "r", encoding="utf-8") as f:
        return json.load(f)


# ─────────────────────────────────────────────
# أزرار اختيار الشارة
# ─────────────────────────────────────────────

class BadgeButtons(View):
    def __init__(self, badges):
        super().__init__(timeout=None)

        for badge in badges:
            self.add_item(Button(label=badge, style=discord.ButtonStyle.primary, custom_id=f"badge_{badge}"))


# ─────────────────────────────────────────────
# كوج نظام الشارات
# ─────────────────────────────────────────────

class BadgeSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ─────────────────────────────
    # اختيار الشارة
    # ─────────────────────────────
    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):

        if not interaction.data or "custom_id" not in interaction.data:
            return

        cid = interaction.data["custom_id"]
        user = interaction.user

        badges = load_badges()
        langs = load_lang()

        lang = langs["users"].get(str(user.id), "ar")

        txt_choose = {
            "ar": "اختر شارتك الشخصية:",
            "en": "Choose your personal badge:"
        }

        txt_saved = {
            "ar": "تم اختيار شارتك:",
            "en": "Your badge has been set:"
        }

        # فتح قائمة الشارات
        if cid == "choose_badge":
            await interaction.response.send_message(
                txt_choose[lang],
                view=BadgeButtons(badges["badges"]),
                ephemeral=True
            )
            return

        # اختيار شارة
        if cid.startswith("badge_"):
            badge = cid.replace("badge_", "")

            badges["users"][str(user.id)] = badge
            save_badges(badges)

            await interaction.response.send_message(
                f"{txt_saved[lang]} **{badge}**",
                ephemeral=True
            )
            return

    # ─────────────────────────────
    # أمر إضافة شارة جديدة
    # ─────────────────────────────
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def addbadge(self, ctx, badge: str):

        data = load_badges()

        if badge in data["badges"]:
            await ctx.send(f"❌ الشارة **{badge}** موجودة بالفعل.")
            return

        data["badges"].append(badge)
        save_badges(data)

        await ctx.send(f"✔️ تم إضافة الشارة الجديدة: **{badge}**")

    # ─────────────────────────────
    # أمر حذف شارة
    # ─────────────────────────────
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def delbadge(self, ctx, badge: str):

        data = load_badges()

        if badge not in data["badges"]:
            await ctx.send(f"❌ الشارة **{badge}** غير موجودة.")
            return

        data["badges"].remove(badge)
        save_badges(data)

        await ctx.send(f"🗑️ تم حذف الشارة: **{badge}**")

    # ─────────────────────────────
    # أمر عرض الشارات
    # ─────────────────────────────
    @commands.command()
    async def badges(self, ctx):

        data = load_badges()
        badge_list = " ".join(data["badges"])

        await ctx.send(f"⭐ **الشارات المتاحة:**\n{badge_list}")


async def setup(bot):
    await bot.add_cog(BadgeSystem(bot))