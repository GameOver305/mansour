import discord
from discord.ext import commands
import json
import os

def load_lang(lang_code):
    path = f"lang/{lang_code}.json"
    if not os.path.exists(path):
        path = "lang/ar.json"
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

class DangMenuView(discord.ui.View):
    def __init__(self, lang):
        super().__init__(timeout=None)
        self.lang = lang

        self.add_item(discord.ui.Button(
            label=self.lang["btn_alliance"],
            style=discord.ButtonStyle.primary,
            custom_id="alliance_menu"
        ))

        self.add_item(discord.ui.Button(
            label=self.lang["btn_teams"],
            style=discord.ButtonStyle.primary,
            custom_id="teams_menu"
        ))

        self.add_item(discord.ui.Button(
            label=self.lang["btn_reminders"],
            style=discord.ButtonStyle.primary,
            custom_id="reminders_menu"
        ))

        self.add_item(discord.ui.Button(
            label=self.lang["btn_redeem"],
            style=discord.ButtonStyle.success,
            custom_id="redeem_menu"
        ))

        self.add_item(discord.ui.Button(
            label=self.lang["btn_admin"],
            style=discord.ButtonStyle.danger,
            custom_id="admin_menu"
        ))

        self.add_item(discord.ui.Button(
            label=self.lang["close"],
            style=discord.ButtonStyle.secondary,
            custom_id="close_menu"
        ))

class DangMenu(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(name="dang", description="فتح القائمة الرئيسية")
    async def dang(self, ctx):
        # تحديد لغة المستخدم
        lang_code = "ar"
        if os.path.exists("config.json"):
            with open("config.json", "r", encoding="utf-8") as f:
                cfg = json.load(f)
                lang_code = cfg.get("default_lang", "ar")

        lang = load_lang(lang_code)

        embed = discord.Embed(
            title=lang["menu_title"],
            description=lang["menu_description"],
            color=discord.Color.blue()
        )

        await ctx.respond(embed=embed, view=DangMenuView(lang))

def setup(bot):
    bot.add_cog(DangMenu(bot))