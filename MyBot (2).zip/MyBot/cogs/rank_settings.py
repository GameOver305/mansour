import discord
from discord.ext import commands
import json
import os

def load_config():
    if not os.path.exists("config.json"):
        return {}
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def save_config(cfg):
    with open("config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=4, ensure_ascii=False)

class RankSettings(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(name="set_rank_color", description="تغيير لون رتبة معينة")
    async def set_rank_color(self, ctx, rank: str, color: str):
        cfg = load_config()

        # التحقق أنه أدمن البوت
        if ctx.author.id not in cfg.get("admins", []):
            return await ctx.respond("هذا الأمر مخصص لأدمن البوت فقط.", ephemeral=True)

        rank = rank.upper()

        if rank not in ["R5", "R4", "R3", "R2", "R1"]:
            return await ctx.respond("الرتبة غير صحيحة.", ephemeral=True)

        cfg["rank_colors"][rank] = color
        save_config(cfg)

        await ctx.respond(f"تم تغيير لون رتبة **{rank}** إلى **{color}** بنجاح.")

def setup(bot):
    bot.add_cog(RankSettings(bot))