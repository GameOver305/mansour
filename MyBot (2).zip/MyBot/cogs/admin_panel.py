# ─────────────────────────────────────────────
# ملف: admin_panel.py
# ─────────────────────────────────────────────

import discord
from discord.ext import commands
from discord.ui import View, Button

class AdminButtons(View):
    def __init__(self):
        super().__init__(timeout=None)

        # زر إصلاح مشاكل البوت
        self.add_item(Button(
            label="🛠️ إصلاح مشاكل البوت",
            style=discord.ButtonStyle.danger,
            custom_id="fix_bot"
        ))


class AdminPanel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # أمر يظهر لوحة الإدارة للأدمن فقط
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def admin(self, ctx):
        embed = discord.Embed(
            title="🛠️ لوحة الإدارة",
            description="اختر ما تريد فعله:",
            color=0xff0000
        )
        await ctx.send(embed=embed, view=AdminButtons())

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):

        if not interaction.data or "custom_id" not in interaction.data:
            return

        cid = interaction.data["custom_id"]

        # ─────────────────────────────
        # زر إصلاح مشاكل البوت
        # ─────────────────────────────
        if cid == "fix_bot":

            # فقط للأدمن
            if not interaction.user.guild_permissions.administrator:
                await interaction.response.send_message(
                    "❌ هذا الزر مخصص للإدارة فقط.",
                    ephemeral=True
                )
                return

            # إصلاح المشاكل الأساسية
            try:
                # إعادة تحميل كل الـ cogs
                for ext in list(self.bot.extensions):
                    await self.bot.reload_extension(ext)

                # إعادة تسجيل الـ views
                self.bot.add_view(AdminButtons())

                await interaction.response.send_message(
                    "✔️ تم إصلاح مشاكل البوت بنجاح!",
                    ephemeral=True
                )

            except Exception as e:
                await interaction.response.send_message(
                    f"حدث خطأ أثناء الإصلاح:\n```{e}```",
                    ephemeral=True
                )


async def setup(bot):
    await bot.add_cog(AdminPanel(bot))