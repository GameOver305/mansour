import discord
from discord.ext import commands
from discord.ui import View, Button
import json
import os

WELCOME_DATA = "data/welcome.json"
LANG_DATA = "data/language.json"

def load_welcome_data():
    if not os.path.exists(WELCOME_DATA):
        with open(WELCOME_DATA, "w", encoding="utf-8") as f:
            json.dump({"sent_to": []}, f, ensure_ascii=False, indent=4)
    with open(WELCOME_DATA, "r", encoding="utf-8") as f:
        return json.load(f)

def save_welcome_data(data):
    with open(WELCOME_DATA, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def load_lang():
    if not os.path.exists(LANG_DATA):
        with open(LANG_DATA, "w", encoding="utf-8") as f:
            json.dump({"users": {}}, f, ensure_ascii=False, indent=4)
    with open(LANG_DATA, "r", encoding="utf-8") as f:
        return json.load(f)


# ───────────────────────────────
#  أزرار الترحيب
# ───────────────────────────────
class WelcomeButtons(View):
    def __init__(self, lang):
        super().__init__(timeout=None)

        rank_text = {
            "R5": "👑 R5",
            "R4": "🛡️ R4",
            "R3": "⚔️ R3",
            "R2": "🌿 R2",
            "R1": "⭐ R1",
        }

        badge_text = "⭐ اختر شارتك الشخصية" if lang == "ar" else "⭐ Choose Your Badge"
        info_text = "ℹ️ معلومات التحالف" if lang == "ar" else "ℹ️ Alliance Info"
        rules_text = "📘 قوانين السيرفر" if lang == "ar" else "📘 Server Rules"
        guide_text = "📝 تعليمات البداية" if lang == "ar" else "📝 Getting Started"

        for r in rank_text:
            self.add_item(Button(
                label=rank_text[r],
                style=discord.ButtonStyle.primary if r in ["R5", "R4"] else discord.ButtonStyle.secondary,
                custom_id=f"rank_{r}"
            ))

        self.add_item(Button(label=badge_text, style=discord.ButtonStyle.success, custom_id="choose_badge"))
        self.add_item(Button(label=info_text, style=discord.ButtonStyle.secondary, custom_id="info_alliance"))
        self.add_item(Button(label=rules_text, style=discord.ButtonStyle.secondary, custom_id="rules"))
        self.add_item(Button(label=guide_text, style=discord.ButtonStyle.secondary, custom_id="start_guide"))


# ───────────────────────────────
#  دالة إنشاء لوحة الترحيب
# ───────────────────────────────
def create_welcome_panel(lang="ar"):
    title = "🎉 مرحبًا بك في تحالف S24" if lang == "ar" else "🎉 Welcome to Alliance S24"
    desc = "اختر إعداداتك للبدء:" if lang == "ar" else "Choose your settings to get started:"

    embed = discord.Embed(title=title, description=desc, color=0x3498db)
    view = WelcomeButtons(lang)

    return embed, view


# ───────────────────────────────
#  كوج الترحيب
# ───────────────────────────────
class WelcomePanel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def send_welcome(self, member, lang):
        embed, view = create_welcome_panel(lang)

        channel = discord.utils.get(member.guild.text_channels, name="welcome")
        if channel:
            await channel.send(embed=embed, view=view)

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):

        if not interaction.data or "custom_id" not in interaction.data:
            return

        cid = interaction.data["custom_id"]

        if cid in ["lang_ar", "lang_en"]:

            user = interaction.user
            lang = "ar" if cid == "lang_ar" else "en"

            data = load_lang()
            data["users"][str(user.id)] = lang
            with open(LANG_DATA, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=4)

            msg = "✔️ تم اختيار اللغة العربية." if lang == "ar" else "✔️ English selected."
            await interaction.response.send_message(msg, ephemeral=True)

            await self.send_welcome(user, lang)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        pass


async def setup(bot):
    await bot.add_cog(WelcomePanel(bot))