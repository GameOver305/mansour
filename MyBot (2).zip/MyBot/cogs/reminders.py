import discord
from discord.ext import commands, tasks
import json
import os
import asyncio
from datetime import datetime, timedelta

def load_lang(lang_code):
    path = f"lang/{lang_code}.json"
    if not os.path.exists(path):
        path = "lang/ar.json"
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def load_config():
    if not os.path.exists("config.json"):
        return {"default_lang": "ar", "admins": []}
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def load_reminders():
    if not os.path.exists("reminders.json"):
        return []
    with open("reminders.json", "r", encoding="utf-8") as f:
        return json.load(f)

def save_reminders(data):
    with open("reminders.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

class Reminders(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.check_reminders.start()

    def cog_unload(self):
        self.check_reminders.cancel()

    def is_admin(self, user_id):
        cfg = load_config()
        return user_id in cfg.get("admins", [])

    @commands.slash_command(name="add_reminder", description="إضافة تذكير جديد")
    async def add_reminder(
        self, ctx,
        title: str,
        message: str,
        minutes_from_now: int,
        repeat_hours: int = 0,
        channel: discord.TextChannel = None,
        role: discord.Role = None
    ):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        if not self.is_admin(ctx.author.id):
            return await ctx.respond(lang["no_permission"], ephemeral=True)

        reminders = load_reminders()

        reminder = {
            "title": title,
            "message": message,
            "time": (datetime.utcnow() + timedelta(minutes=minutes_from_now)).timestamp(),
            "repeat": repeat_hours,
            "channel": channel.id if channel else None,
            "role": role.id if role else None,
            "user": ctx.author.id
        }

        reminders.append(reminder)
        save_reminders(reminders)

        await ctx.respond(f"تم إضافة التذكير **{title}** بنجاح!")

    @commands.slash_command(name="reminders", description="عرض جميع التذكيرات")
    async def reminders_list(self, ctx):
        reminders = load_reminders()

        if not reminders:
            return await ctx.respond("لا يوجد تذكيرات حالياً.", ephemeral=True)

        embed = discord.Embed(
            title="قائمة التذكيرات",
            color=discord.Color.orange()
        )

        for r in reminders:
            time_str = datetime.utcfromtimestamp(r["time"]).strftime("%Y-%m-%d %H:%M UTC")
            embed.add_field(
                name=r["title"],
                value=f"الوقت: {time_str}\nالتكرار: كل {r['repeat']} ساعة" if r["repeat"] else "مرة واحدة",
                inline=False
            )

        await ctx.respond(embed=embed)

    @commands.slash_command(name="delete_reminder", description="حذف تذكير")
    async def delete_reminder(self, ctx, title: str):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        if not self.is_admin(ctx.author.id):
            return await ctx.respond(lang["no_permission"], ephemeral=True)

        reminders = load_reminders()

        new_list = [r for r in reminders if r["title"] != title]

        if len(new_list) == len(reminders):
            return await ctx.respond("لم يتم العثور على تذكير بهذا الاسم.", ephemeral=True)

        save_reminders(new_list)
        await ctx.respond(f"تم حذف التذكير **{title}**.")

    @tasks.loop(seconds=30)
    async def check_reminders(self):
        reminders = load_reminders()
        changed = False
        now = datetime.utcnow().timestamp()

        for r in reminders:
            if now >= r["time"]:
                # إرسال التذكير
                try:
                    if r["channel"]:
                        channel = self.bot.get_channel(r["channel"])
                        if channel:
                            mention = f"<@&{r['role']}>" if r["role"] else ""
                            await channel.send(f"{mention}\n**{r['title']}**\n{r['message']}")
                    else:
                        user = await self.bot.fetch_user(r["user"])
                        await user.send(f"**{r['title']}**\n{r['message']}")
                except:
                    pass

                # تكرار أو حذف
                if r["repeat"] > 0:
                    r["time"] = (datetime.utcnow() + timedelta(hours=r["repeat"])).timestamp()
                else:
                    reminders.remove(r)

                changed = True

        if changed:
            save_reminders(reminders)

def setup(bot):
    bot.add_cog(Reminders(bot))