import discord
from discord.ext import commands
from cogs.welcome_panel import load_lang

class WelcomeButtonsHandler(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):

        if not interaction.data or "custom_id" not in interaction.data:
            return

        cid = interaction.data["custom_id"]

        # جلب لغة المستخدم
        data = load_lang()
        lang = data["users"].get(str(interaction.user.id), "ar")

        # ─────────────────────────────
        #  أزرار الرتب
        # ─────────────────────────────
        if cid.startswith("rank_"):
            rank = cid.replace("rank_", "")
            msg = f"✔️ تم اختيار رتبة **{rank}**" if lang == "ar" else f"✔️ Rank **{rank}** selected"
            await interaction.response.send_message(msg, ephemeral=True)
            return

        # ─────────────────────────────
        #  زر الشارة
        # ─────────────────────────────
        if cid == "choose_badge":
            msg = "⭐ اختر شارتك من القائمة القادمة" if lang == "ar" else "⭐ Choose your badge from the next menu"
            await interaction.response.send_message(msg, ephemeral=True)
            return

        # ─────────────────────────────
        #  معلومات التحالف
        # ─────────────────────────────
        if cid == "info_alliance":
            text = "ℹ️ معلومات التحالف: …" if lang == "ar" else "ℹ️ Alliance information: …"
            await interaction.response.send_message(text, ephemeral=True)
            return

        # ─────────────────────────────
        #  القوانين
        # ─────────────────────────────
        if cid == "rules":
            text = "📘 قوانين السيرفر: …" if lang == "ar" else "📘 Server rules: …"
            await interaction.response.send_message(text, ephemeral=True)
            return

        # ─────────────────────────────
        #  تعليمات البداية
        # ─────────────────────────────
        if cid == "start_guide":
            text = "📝 تعليمات البداية: …" if lang == "ar" else "📝 Getting started: …"
            await interaction.response.send_message(text, ephemeral=True)
            return


async def setup(bot):
    await bot.add_cog(WelcomeButtonsHandler(bot))