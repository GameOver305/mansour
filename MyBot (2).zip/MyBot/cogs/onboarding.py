import discord
from discord.ext import commands
import json
import os

def load_config():
    if not os.path.exists("config.json"):
        return {"onboarding_enabled": False}
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def save_config(cfg):
    with open("config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=4, ensure_ascii=False)

class OnboardingView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="تسجيل الدخول", style=discord.ButtonStyle.green)
    async def login_button(self, button, interaction):
        await interaction.response.send_message(
            "اضغط على الأمر التالي للتسجيل:\n`/login`",
            ephemeral=True
        )

    @discord.ui.button(label="اختيار فريق", style=discord.ButtonStyle.blurple)
    async def team_button(self, button, interaction):
        await interaction.response.send_message(
            "استخدم `/teams_menu` لاختيار فريق.",
            ephemeral=True
        )

    @discord.ui.button(label="معلومات التحالف", style=discord.ButtonStyle.gray)
    async def alliance_button(self, button, interaction):
        await interaction.response.send_message(
            "استخدم `/alliance_info` لعرض معلومات التحالف.",
            ephemeral=True
        )

class Onboarding(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(name="toggle_onboarding", description="تفعيل أو تعطيل نظام الترحيب التفاعلي")
    async def toggle_onboarding(self, ctx):
        cfg = load_config()

        # فقط المالك
        if ctx.author.id != ctx.guild.owner_id:
            return await ctx.respond("هذا الأمر للمالك فقط.", ephemeral=True)

        cfg["onboarding_enabled"] = not cfg.get("onboarding_enabled", False)
        save_config(cfg)

        status = "مفعل" if cfg["onboarding_enabled"] else "متوقف"
        await ctx.respond(f"تم تغيير حالة نظام الترحيب إلى: **{status}**")

    @commands.Cog.listener()
    async def on_member_join(self, member):
        cfg = load_config()

        if not cfg.get("onboarding_enabled", False):
            return

        try:
            await member.send(
                "مرحبًا بك في السيرفر! اختر أحد الخيارات التالية:",
                view=OnboardingView()
            )
        except:
            pass

def setup(bot):
    bot.add_cog(Onboarding(bot))