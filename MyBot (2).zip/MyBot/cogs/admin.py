import discord
from discord.ext import commands
import json
import os

def load_lang(lang_code):
    path = f"lang/{lang_code}.json"
    if not os.path.exists(path):
        path = "lang/ar.json"
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def load_config():
    if not os.path.exists("config.json"):
        return {"default_lang": "ar", "admins": []}
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def save_config(cfg):
    with open("config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=4, ensure_ascii=False)

class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def is_admin(self, user_id):
        cfg = load_config()
        return user_id in cfg.get("admins", [])

    @commands.slash_command(name="addadmin", description="إضافة أدمن للبوت")
    async def addadmin(self, ctx, member: discord.Member):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        if not self.is_admin(ctx.author.id):
            return await ctx.respond(lang["no_permission"], ephemeral=True)

        if member.id in cfg["admins"]:
            return await ctx.respond("هذا المستخدم أدمن بالفعل.", ephemeral=True)

        cfg["admins"].append(member.id)
        save_config(cfg)

        await ctx.respond(f"تم إضافة {member.mention} كأدمن.")

    @commands.slash_command(name="removeadmin", description="إزالة أدمن من البوت")
    async def removeadmin(self, ctx, member: discord.Member):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        if not self.is_admin(ctx.author.id):
            return await ctx.respond(lang["no_permission"], ephemeral=True)

        if member.id not in cfg["admins"]:
            return await ctx.respond("هذا المستخدم ليس أدمن.", ephemeral=True)

        cfg["admins"].remove(member.id)
        save_config(cfg)

        await ctx.respond(f"تم إزالة {member.mention} من الأدمن.")

    @commands.slash_command(name="admins", description="عرض قائمة الأدمن")
    async def admins(self, ctx):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        admin_ids = cfg.get("admins", [])
        if not admin_ids:
            return await ctx.respond("لا يوجد أدمن حتى الآن.", ephemeral=True)

        admin_list = "\n".join([f"<@{i}>" for i in admin_ids])
        embed = discord.Embed(
            title="قائمة الأدمن",
            description=admin_list,
            color=discord.Color.gold()
        )

        await ctx.respond(embed=embed)

def setup(bot):
    bot.add_cog(Admin(bot))