import discord
from discord.ext import commands
import json
import os

def load_lang(lang_code):
    path = f"lang/{lang_code}.json"
    if not os.path.exists(path):
        path = "lang/ar.json"
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def load_config():
    if not os.path.exists("config.json"):
        return {"default_lang": "ar", "admins": []}
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def load_alliance():
    if not os.path.exists("alliance.json"):
        return {"name": None, "description": None, "leaders": [], "members": []}
    with open("alliance.json", "r", encoding="utf-8") as f:
        return json.load(f)

def save_alliance(data):
    with open("alliance.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

class Alliance(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def is_admin(self, user_id):
        cfg = load_config()
        return user_id in cfg.get("admins", [])

    @commands.slash_command(name="create_alliance", description="إنشاء تحالف جديد")
    async def create_alliance(self, ctx, name: str, description: str = None):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        if not self.is_admin(ctx.author.id):
            return await ctx.respond(lang["no_permission"], ephemeral=True)

        data = load_alliance()

        if data["name"] is not None:
            return await ctx.respond("يوجد تحالف بالفعل. احذف القديم أولاً.", ephemeral=True)

        data["name"] = name
        data["description"] = description or "لا يوجد وصف"
        data["leaders"] = [ctx.author.id]
        data["members"] = []

        save_alliance(data)

        await ctx.respond(f"تم إنشاء التحالف **{name}** بنجاح!")

    @commands.slash_command(name="delete_alliance", description="حذف التحالف")
    async def delete_alliance(self, ctx):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        if not self.is_admin(ctx.author.id):
            return await ctx.respond(lang["no_permission"], ephemeral=True)

        data = load_alliance()

        if data["name"] is None:
            return await ctx.respond("لا يوجد تحالف لحذفه.", ephemeral=True)

        save_alliance({"name": None, "description": None, "leaders": [], "members": []})

        await ctx.respond("تم حذف التحالف بنجاح.")

    @commands.slash_command(name="alliance_info", description="عرض معلومات التحالف")
    async def alliance_info(self, ctx):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))
        data = load_alliance()

        if data["name"] is None:
            return await ctx.respond("لا يوجد تحالف حتى الآن.", ephemeral=True)

        leaders = "\n".join([f"<@{i}>" for i in data["leaders"]]) or "لا يوجد"
        members = "\n".join([f"<@{i}>" for i in data["members"]]) or "لا يوجد"

        embed = discord.Embed(
            title=f"تحالف: {data['name']}",
            description=data["description"],
            color=discord.Color.blue()
        )

        embed.add_field(name="القادة", value=leaders, inline=False)
        embed.add_field(name="الأعضاء", value=members, inline=False)

        await ctx.respond(embed=embed)

def setup(bot):
    bot.add_cog(Alliance(bot))