import discord
from discord.ext import commands
import json
import os

def load_lang(lang_code):
    path = f"lang/{lang_code}.json"
    if not os.path.exists(path):
        path = "lang/ar.json"
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def load_config():
    if not os.path.exists("config.json"):
        return {"default_lang": "ar", "admins": []}
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def load_teams():
    if not os.path.exists("teams.json"):
        return {}
    with open("teams.json", "r", encoding="utf-8") as f:
        return json.load(f)

def save_teams(data):
    with open("teams.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

class Teams(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def is_admin(self, user_id):
        cfg = load_config()
        return user_id in cfg.get("admins", [])

    @commands.slash_command(name="create_team", description="إنشاء فريق جديد")
    async def create_team(self, ctx, team_name: str):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        if not self.is_admin(ctx.author.id):
            return await ctx.respond(lang["no_permission"], ephemeral=True)

        teams = load_teams()

        if team_name in teams:
            return await ctx.respond("هذا الفريق موجود بالفعل.", ephemeral=True)

        teams[team_name] = {
            "leaders": [ctx.author.id],
            "members": []
        }

        save_teams(teams)

        await ctx.respond(f"تم إنشاء الفريق **{team_name}** بنجاح!")

    @commands.slash_command(name="delete_team", description="حذف فريق")
    async def delete_team(self, ctx, team_name: str):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        if not self.is_admin(ctx.author.id):
            return await ctx.respond(lang["no_permission"], ephemeral=True)

        teams = load_teams()

        if team_name not in teams:
            return await ctx.respond("هذا الفريق غير موجود.", ephemeral=True)

        del teams[team_name]
        save_teams(teams)

        await ctx.respond(f"تم حذف الفريق **{team_name}**.")

    @commands.slash_command(name="team_info", description="عرض معلومات فريق")
    async def team_info(self, ctx, team_name: str):
        teams = load_teams()

        if team_name not in teams:
            return await ctx.respond("هذا الفريق غير موجود.", ephemeral=True)

        data = teams[team_name]

        leaders = "\n".join([f"<@{i}>" for i in data["leaders"]]) or "لا يوجد"
        members = "\n".join([f"<@{i}>" for i in data["members"]]) or "لا يوجد"

        embed = discord.Embed(
            title=f"فريق: {team_name}",
            color=discord.Color.green()
        )

        embed.add_field(name="القادة", value=leaders, inline=False)
        embed.add_field(name="الأعضاء", value=members, inline=False)

        await ctx.respond(embed=embed)

    @commands.slash_command(name="add_team_leader", description="إضافة قائد لفريق")
    async def add_team_leader(self, ctx, team_name: str, member: discord.Member):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        if not self.is_admin(ctx.author.id):
            return await ctx.respond(lang["no_permission"], ephemeral=True)

        teams = load_teams()

        if team_name not in teams:
            return await ctx.respond("الفريق غير موجود.", ephemeral=True)

        if member.id in teams[team_name]["leaders"]:
            return await ctx.respond("هذا المستخدم قائد بالفعل.", ephemeral=True)

        teams[team_name]["leaders"].append(member.id)
        save_teams(teams)

        await ctx.respond(f"تم إضافة {member.mention} كقائد لفريق **{team_name}**.")

    @commands.slash_command(name="remove_team_leader", description="إزالة قائد من فريق")
    async def remove_team_leader(self, ctx, team_name: str, member: discord.Member):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        if not self.is_admin(ctx.author.id):
            return await ctx.respond(lang["no_permission"], ephemeral=True)

        teams = load_teams()

        if team_name not in teams:
            return await ctx.respond("الفريق غير موجود.", ephemeral=True)

        if member.id not in teams[team_name]["leaders"]:
            return await ctx.respond("هذا المستخدم ليس قائدًا.", ephemeral=True)

        teams[team_name]["leaders"].remove(member.id)
        save_teams(teams)

        await ctx.respond(f"تم إزالة {member.mention} من قادة فريق **{team_name}**.")

    @commands.slash_command(name="add_team_member", description="إضافة عضو لفريق")
    async def add_team_member(self, ctx, team_name: str, member: discord.Member):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        if not self.is_admin(ctx.author.id):
            return await ctx.respond(lang["no_permission"], ephemeral=True)

        teams = load_teams()

        if team_name not in teams:
            return await ctx.respond("الفريق غير موجود.", ephemeral=True)

        if member.id in teams[team_name]["members"]:
            return await ctx.respond("هذا المستخدم عضو بالفعل.", ephemeral=True)

        teams[team_name]["members"].append(member.id)
        save_teams(teams)

        await ctx.respond(f"تم إضافة {member.mention} كعضو في فريق **{team_name}**.")

    @commands.slash_command(name="remove_team_member", description="إزالة عضو من فريق")
    async def remove_team_member(self, ctx, team_name: str, member: discord.Member):
        cfg = load_config()
        lang = load_lang(cfg.get("default_lang", "ar"))

        if not self.is_admin(ctx.author.id):
            return await ctx.respond(lang["no_permission"], ephemeral=True)

        teams = load_teams()

        if team_name not in teams:
            return await ctx.respond("الفريق غير موجود.", ephemeral=True)

        if member.id not in teams[team_name]["members"]:
            return await ctx.respond("هذا المستخدم ليس عضوًا.", ephemeral=True)

        teams[team_name]["members"].remove(member.id)
        save_teams(teams)

        await ctx.respond(f"تم إزالة {member.mention} من فريق **{team_name}**.")

def setup(bot):
    bot.add_cog(Teams(bot))