# ─────────────────────────────────────────────
# ملف: language_system.py
# ─────────────────────────────────────────────

import discord
from discord.ext import commands
from discord.ui import View, Button
import json
import os

LANG_DATA = "data/language.json"

def load_lang():
    if not os.path.exists(LANG_DATA):
        with open(LANG_DATA, "w", encoding="utf-8") as f:
            json.dump({"users": {}}, f, ensure_ascii=False, indent=4)
    with open(LANG_DATA, "r", encoding="utf-8") as f:
        return json.load(f)

def save_lang(data):
    with open(LANG_DATA, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)


# ─────────────────────────────────────────────
# أزرار اختيار اللغة
# ─────────────────────────────────────────────

class LanguageButtons(View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(Button(label="🇸🇦 العربية", style=discord.ButtonStyle.primary, custom_id="lang_ar"))
        self.add_item(Button(label="🇺🇸 English", style=discord.ButtonStyle.secondary, custom_id="lang_en"))


class LanguageSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # عند دخول عضو جديد → نرسل له اختيار اللغة فقط
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):

        channel = discord.utils.get(member.guild.text_channels, name="welcome")
        if channel is None:
            return

        embed = discord.Embed(
            title="🌍 اختر لغتك",
            description="Please select your language:",
            color=0x00aaff
        )

        await channel.send(embed=embed, view=LanguageButtons())

    # استقبال ضغطات اللغة
    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):

        if not interaction.data or "custom_id" not in interaction.data:
            return

        cid = interaction.data["custom_id"]
        user = interaction.user
        data = load_lang()

        # ─────────────────────────────
        # اختيار العربية
        # ─────────────────────────────
        if cid == "lang_ar":
            data["users"][str(user.id)] = "ar"
            save_lang(data)

            await interaction.response.send_message(
                "✔️ تم اختيار اللغة العربية.\nسيتم عرض كل شيء بالعربية.",
                ephemeral=True
            )
            return

        # ─────────────────────────────
        # اختيار الإنجليزية
        # ─────────────────────────────
        if cid == "lang_en":
            data["users"][str(user.id)] = "en"
            save_lang(data)

            await interaction.response.send_message(
                "✔️ English selected.\nEverything will appear in English.",
                ephemeral=True
            )
            return


async def setup(bot):
    await bot.add_cog(LanguageSystem(bot))