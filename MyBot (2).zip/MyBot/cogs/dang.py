import discord
from discord import app_commands
from discord.ext import commands

class Dang(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="dang", description="إرسال لوحة الترحيب يدويًا")
    async def dang(self, interaction: discord.Interaction):

        try:
            from cogs.welcome_panel import create_welcome_panel, load_lang

            data = load_lang()
            user_id = str(interaction.user.id)
            lang = data["users"].get(user_id, "ar")

            embed, view = create_welcome_panel(lang)

            await interaction.response.send_message(embed=embed, view=view)

        except Exception as e:
            await interaction.response.send_message(
                f"⚠️ حدث خطأ داخل الأمر:\n```{e}```",
                ephemeral=True
            )

async def setup(bot):
    await bot.add_cog(Dang(bot))