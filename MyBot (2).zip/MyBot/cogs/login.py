import discord
from discord.ext import commands
import json
import os

def load_users():
    if not os.path.exists("users.json"):
        return {"users": {}}
    with open("users.json", "r", encoding="utf-8") as f:
        return json.load(f)

def save_users(data):
    with open("users.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

class Login(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(name="login", description="تسجيل دخول المستخدم داخل البوت")
    async def login(self, ctx, name: str):
        users = load_users()

        users["users"][str(ctx.author.id)] = {
            "name": name,
            "team": None,
            "alliance": None,
            "role": "member"
        }

        save_users(users)

        await ctx.respond(f"تم تسجيل دخولك يا **{name}** بنجاح!", ephemeral=True)

    @commands.slash_command(name="logout", description="تسجيل خروج المستخدم")
    async def logout(self, ctx):
        users = load_users()

        if str(ctx.author.id) not in users["users"]:
            return await ctx.respond("أنت غير مسجل دخول.", ephemeral=True)

        del users["users"][str(ctx.author.id)]
        save_users(users)

        await ctx.respond("تم تسجيل خروجك بنجاح.", ephemeral=True)

    @commands.slash_command(name="profile", description="عرض ملفك الشخصي")
    async def profile(self, ctx):
        users = load_users()

        if str(ctx.author.id) not in users["users"]:
            return await ctx.respond("أنت غير مسجل دخول.", ephemeral=True)

        data = users["users"][str(ctx.author.id)]

        embed = discord.Embed(
            title=f"ملف {data['name']}",
            color=discord.Color.blue()
        )

        embed.add_field(name="الاسم", value=data["name"], inline=False)
        embed.add_field(name="الدور", value=data["role"], inline=False)
        embed.add_field(name="الفريق", value=data["team"] or "غير محدد", inline=False)
        embed.add_field(name="التحالف", value=data["alliance"] or "غير محدد", inline=False)

        await ctx.respond(embed=embed, ephemeral=True)

def setup(bot):
    bot.add_cog(Login(bot))